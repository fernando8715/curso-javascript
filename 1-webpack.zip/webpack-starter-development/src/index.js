
//El import hago referencia al archivo js que esta en la carpeta js
import {saludar} from './js/componentes'; 
import './styles.css';

const nombre = 'Fernando';

saludar(nombre);









